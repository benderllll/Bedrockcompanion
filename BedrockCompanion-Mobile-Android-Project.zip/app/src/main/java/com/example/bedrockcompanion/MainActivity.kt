package com.example.bedrockcompanion

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF151A28)
private val Panel2 = Color(0xFF20273A)
private val Purple = Color(0xFFA78BFA)
private val Mint = Color(0xFF62E6C5)
private val Txt = Color(0xFFF5F6FB)
private val Muted = Color(0xFFA0A9BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MobileApp(applicationContext) }
    }
}

private data class Module(val name: String, val group: String, val description: String, val defaultOn: Boolean = false)
private val modules = listOf(
    Module("Crosshair Preview", "Visuals", "Preview crosshair styles", true),
    Module("HUD Grid", "HUD", "Touch-friendly alignment guides", true),
    Module("Coordinate Notes", "Build", "Keep your build locations"),
    Module("Block Palette", "Build", "Choose materials for your plans", true),
    Module("Theme Glow", "Visuals", "Accent styling for this app", true),
    Module("Touch Layout Guide", "HUD", "Preview screen safe areas"),
    Module("Structure Planner", "Build", "Estimate structure block counts"),
    Module("Session Checklist", "Tools", "Prepare before a session")
)

@Composable
private fun MobileApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("bedrock_mobile", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var active by remember { mutableStateOf(modules.associate { it.name to prefs.getBoolean(it.name, it.defaultOn) }) }
    var crosshair by remember { mutableStateOf(prefs.getString("crosshair", "Dot") ?: "Dot") }
    var theme by remember { mutableStateOf(prefs.getString("theme", "Violet") ?: "Violet") }
    var profile by remember { mutableStateOf(prefs.getString("profile", "Default") ?: "Default") }
    var notice by remember { mutableStateOf("Ready to customize") }
    var structure by remember { mutableStateOf("Starter base") }
    var width by remember { mutableStateOf("12") }
    var depth by remember { mutableStateOf("10") }
    var height by remember { mutableStateOf("6") }
    var material by remember { mutableStateOf("Stone Bricks") }
    var coordDraft by remember { mutableStateOf("") }
    var coords by remember { mutableStateOf(prefs.getString("coords", "") ?: "") }
    var x by remember { mutableFloatStateOf(prefs.getFloat("x", .4f)) }
    var y by remember { mutableFloatStateOf(prefs.getFloat("y", .4f)) }
    var scale by remember { mutableFloatStateOf(prefs.getFloat("scale", 1f)) }

    fun save() {
        prefs.edit().apply {
            active.forEach { (k, v) -> putBoolean(k, v) }
            putString("crosshair", crosshair); putString("theme", theme)
            putString("profile", profile); putString("coords", coords)
            putFloat("x", x); putFloat("y", y); putFloat("scale", scale)
            apply()
        }
        notice = "Settings saved on this phone."
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Mint, background = Bg, surface = Panel, onSurface = Txt)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF10131D), contentColor = Txt) {
                    listOf("Home" to Icons.Default.Home, "Modules" to Icons.Default.Tune, "Build" to Icons.Default.GridView, "HUD" to Icons.Default.DashboardCustomize, "Settings" to Icons.Default.Settings).forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = page == label, onClick = { page = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Txt, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().background(Color(0xFF10131D)).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Purple, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Bg, modifier = Modifier.size(27.dp)) }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BEDROCK", fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("MOBILE COMPANION", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Box(Modifier.background(Color(0xFF16372F), RoundedCornerShape(30.dp)).padding(horizontal = 10.dp, vertical = 7.dp)) { Text("● READY", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                }
                Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 14.dp)) {
                    when (page) {
                        "Home" -> {
                            Eyebrow("MOBILE CLIENT TOOLKIT")
                            Text("Your setup.", fontSize = 30.sp, fontWeight = FontWeight.Black)
                            Text("A touch-first companion for Minecraft Bedrock.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            CardPanel {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("QUICK STATUS", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                        Text("${active.values.count { it }} features enabled", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                        Text("Companion settings only", color = Muted, fontSize = 12.sp)
                                    }
                                    Icon(Icons.Default.Bolt, null, tint = Mint, modifier = Modifier.size(38.dp))
                                }
                                Button(onClick = { page = "Modules" }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(8.dp)); Text("Open module menu") }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                QuickTile("Build Lab", "Plans & blocks", Icons.Default.GridView, Modifier.weight(1f)) { page = "Build" }
                                QuickTile("HUD Preview", "Touch layout", Icons.Default.DashboardCustomize, Modifier.weight(1f)) { page = "HUD" }
                            }
                            Spacer(Modifier.height(12.dp))
                            CardPanel {
                                Text("IMPORTANT", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("This is an independent companion app. It does not inject into Minecraft or modify the real in-game HUD.", color = Muted, fontSize = 12.sp)
                            }
                        }
                        "Modules" -> {
                            Eyebrow("FEATURE CONTROL")
                            Text("Modules", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Field(search, { search = it }, "Search features…")
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("All", "Build", "HUD", "Visuals", "Tools").forEach { FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it, fontSize = 10.sp) }) }
                            }
                            Spacer(Modifier.height(8.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                                items(modules.filter { (filter == "All" || it.group == filter) && (it.name.contains(search, true) || it.description.contains(search, true)) }) { m ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(42.dp).background(Panel2, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                                Icon(when(m.group) { "Build" -> Icons.Default.GridView; "HUD" -> Icons.Default.DashboardCustomize; "Visuals" -> Icons.Default.Visibility; else -> Icons.Default.Bolt }, null, tint = if (active[m.name] == true) Mint else Muted)
                                            }
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(m.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                Text(m.description, color = Muted, fontSize = 10.sp)
                                                Text(m.group.uppercase(), color = Purple, fontSize = 9.sp, letterSpacing = 1.sp)
                                            }
                                            Switch(checked = active[m.name] == true, onCheckedChange = { checked -> active = active.toMutableMap().also { it[m.name] = checked }; prefs.edit().putBoolean(m.name, checked).apply() })
                                        }
                                    }
                                }
                            }
                        }
                        "Build" -> {
                            Eyebrow("BUILD LAB"); Text("Structure planner", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("Plan dimensions and keep coordinates.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            CardPanel {
                                Field(structure, { structure = it }, "Structure name")
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Field(width, { width = it.filter(Char::isDigit) }, "Width", Modifier.weight(1f))
                                    Field(depth, { depth = it.filter(Char::isDigit) }, "Depth", Modifier.weight(1f))
                                    Field(height, { height = it.filter(Char::isDigit) }, "Height", Modifier.weight(1f))
                                }
                                Text("Main block", color = Muted, fontSize = 12.sp)
                                listOf("Stone Bricks", "Oak Planks", "Deepslate", "Quartz").forEach { b ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { material = b }.padding(vertical = 1.dp)) {
                                        RadioButton(selected = material == b, onClick = { material = b })
                                        Text(b, fontSize = 13.sp)
                                    }
                                }
                                val total = (width.toLongOrNull() ?: 0) * (depth.toLongOrNull() ?: 0) * (height.toLongOrNull() ?: 0)
                                Text("Volume estimate: $total blocks", fontWeight = FontWeight.Bold)
                                Button(onClick = { notice = "“$structure”: $total blocks at $material." }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Calculate build") }
                                Text(notice, color = Mint, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(12.dp))
                            CardPanel {
                                Text("COORDINATE NOTES", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Field(coordDraft, { coordDraft = it }, "Base: X 120, Y 64, Z -30")
                                Button(onClick = { if (coordDraft.isNotBlank()) { coords = (coords.lines().filter { it.isNotBlank() } + coordDraft).distinct().joinToString("\n"); coordDraft = ""; save() } }, modifier = Modifier.fillMaxWidth()) { Text("Save coordinate") }
                                Text(coords.ifBlank { "No saved locations yet." }, color = Muted, fontSize = 12.sp)
                            }
                        }
                        "HUD" -> {
                            Eyebrow("TOUCH LAYOUT"); Text("HUD preview", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text("Move and scale the preview widget.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            CardPanel {
                                Box(Modifier.fillMaxWidth().height(230.dp).background(Color(0xFF0C101A), RoundedCornerShape(15.dp)).padding(10.dp)) {
                                    Text("PHONE SAFE AREA", color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.TopStart))
                                    Column(Modifier.align(Alignment.TopStart).offset(x = (x * 100).dp, y = (y * 100).dp).background(Panel2, RoundedCornerShape(10.dp)).padding((8 * scale).dp)) {
                                        Text("✦ HUD WIDGET", color = Mint, fontSize = (10 * scale).sp, fontWeight = FontWeight.Bold)
                                        Text("XYZ 120 / 64 / -30", color = Txt, fontSize = (9 * scale).sp)
                                    }
                                    Text(if (crosshair == "Plus") "+" else if (crosshair == "Circle") "⊙" else "•", color = Purple, fontSize = 30.sp, modifier = Modifier.align(Alignment.Center))
                                    Text("TOUCH ZONE", color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomEnd))
                                }
                                Text("Horizontal position", color = Muted, fontSize = 12.sp); Slider(value = x, onValueChange = { x = it })
                                Text("Vertical position", color = Muted, fontSize = 12.sp); Slider(value = y, onValueChange = { y = it })
                                Text("Widget size", color = Muted, fontSize = 12.sp); Slider(value = scale, onValueChange = { scale = it }, valueRange = .7f..1.5f)
                                Button(onClick = { save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Save layout") }
                                Text("Preview only — it does not move Minecraft's actual HUD.", color = Muted, fontSize = 11.sp)
                            }
                        }
                        else -> {
                            Eyebrow("APP SETTINGS"); Text("Personalize", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            CardPanel {
                                Text("CROSSHAIR PREVIEW", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Dot", "Plus", "Circle").forEach { FilterChip(selected = crosshair == it, onClick = { crosshair = it; save() }, label = { Text(it) }) } }
                                Box(Modifier.fillMaxWidth().height(65.dp).background(Color(0xFF0C101A), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(if (crosshair == "Plus") "+" else if (crosshair == "Circle") "⊙" else "•", color = Purple, fontSize = 32.sp) }
                                Text("ACCENT THEME", color = Purple, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Violet", "Mint", "Blue").forEach { FilterChip(selected = theme == it, onClick = { theme = it; save() }, label = { Text(it) }) } }
                                Field(profile, { profile = it }, "Profile name")
                                Button(onClick = { save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save settings") }
                                Text(notice, color = Mint, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(12.dp))
                            CardPanel { Text("ABOUT", fontWeight = FontWeight.Bold); Text("Original mobile companion prototype. Not affiliated with Corz Client or Mojang. No game injection, combat automation, hidden-player ESP, or anti-cheat bypass.", color = Muted, fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Eyebrow(text: String) { Text(text, color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp) }
@Composable private fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content)
    }
}
@Composable private fun Field(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            if (value.isEmpty()) Text(placeholder, color = Muted, fontSize = 12.sp)
            BasicTextField(value = value, onValueChange = onChange, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Txt, fontSize = 13.sp), modifier = Modifier.fillMaxWidth())
        }
    }
}
@Composable private fun QuickTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(26.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}
