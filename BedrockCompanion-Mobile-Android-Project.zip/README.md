# Bedrock Mobile Companion

Mobile-first Android app source project with bottom navigation, large touch targets, module toggles, build planner, coordinate notes, HUD preview controls, crosshair/theme previews, and local settings.

This is an original companion app, not an exact copy of Corz Client. It does not inject into Minecraft, modify the game's real HUD, automate combat, reveal hidden players, bypass anti-cheat, or connect directly to multiplayer servers.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Allow Gradle sync to finish (internet may be needed).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Transfer the generated APK to your Android phone and install it.

Minimum Android API 26. Portrait-first layout optimized for phones.
